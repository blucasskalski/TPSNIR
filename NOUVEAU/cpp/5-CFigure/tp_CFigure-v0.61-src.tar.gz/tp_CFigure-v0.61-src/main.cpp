// main.cpp

#include "cdraft.h"
#include <string>
using namespace std ;

int main(int argc, char** argv )
{
	// Traitement de l'option '-v' (ligne de commandes)

	if ( argc > 1 ) {
		string opt( *++argv ) ;
		if ( opt == "-v" )	CDraft::setVerbose( true ) ;
	}

	// Construction de l'espace graphique

	CDraft	draft( 800, 600 ) ;

	draft.setX( 400 ) ;
	draft.setY( 300 ) ;
	draft.setScale( 40 ) ;
	draft.draw( true ) ;

	draft.updateScreen() ;
	draft.run() ;

	return 0 ;
}
