// cjulia.cpp

#include "cjulia.h"

CJulia::CJulia(int n, double a, double b ) : nMax(n)
{
	//
}

int CJulia::dot(double x, double y )
{
	//
	return -1 ;
}

void CJulia::init(const complex<double>& Z )
{
	//
}

