// cvue.cpp

#include "cvue.h"
#include "cjulia.h"

// constructeur
// par défaut, le repère complexe est initialisé avec le plan physique

CVue::CVue(int w, int h )
	: XamGraph( w, h, "Julia & Mandelbrot" )
	, xMin( 0 )
	, xMax( w - 1 )
	, yMin( h - 1 )
	, yMax( 0 )
	, capture( false )
	, fractale( NULL )
{
	//

	if ( fractale != NULL ) {
		//
	}

	mainColor = stringToColor("#0080ff") ;

	clearScreen( XAM_WHITE ) ;
	drawFractal() ;
}

// Début ou fin d'une capture rectangulaire pour zoom

void CVue::initCapture(int x, int y )
{

	if ( !capture ) {			// premier point
		//
		drawCapture() ;
	}
	else {						// deuxième point
		//

		// dessin de la nouvelle fractale

		setDrawingArea( XAM_DRAWING_BITMAP ) ;
		drawFractal() ;
		updateScreen() ;
		setDrawingArea( XAM_DRAWING_SCREEN ) ;
	}
}

// Modification dynamique du rectangle de capture

void CVue::changeCapture(int x, int y )
{
	//
}

// Annulation de la capture en cours

void CVue::stopCapture()
{
	//
}

// Dessin du rectangle de capture (mode XOR)

void CVue::drawCapture()
{
	setWriteMode( XAM_MODE_XOR ) ;
	setColor( XAM_GREEN ) ;

	int left   = ( xBegin < xEnd ? xBegin : xEnd ) ;
	int top    = ( yBegin < yEnd ? yBegin : yEnd ) ;
	int right  = ( xBegin < xEnd ? xEnd : xBegin ) ;
	int bottom = ( yBegin < yEnd ? yEnd : yBegin ) ;

	rectangle( left, top, right - left , bottom - top ) ;
	setWriteMode( XAM_MODE_COPY ) ;

	updateScreen() ;
}

// Dessin point par point de la fractale

void CVue::drawFractal()
{
	if ( fractale == NULL )	return ;

	//

	updateScreen() ;
}

// affiche position courante de la souris dans le repère complexe

void CVue::drawLogicalPosition(int x, int y )
{
	char	buf[80] ;
	sprintf(buf, "[ %+15.10f ; %+15.10f ]", xLogical(x), yLogical(y) ) ;

	setColor( XAM_WHITE ) ;
	int posy = maxY() - textHeight() - 4 ;
	filledRectangle(0, posy, textWidth(buf) + 4, textHeight() + 4 ) ;
	setColor( XAM_BLACK ) ;
	textOut( 2, posy + 2, buf ) ;

	updateScreen() ;
}

// couleurs...

int  CVue::scaledColor(int n )
{
	int r = (int)( red( mainColor ) * ( n % 17 ) / 16.0 ) ;
	int v = (int)( green( mainColor ) * ( n % 17 ) / 16.0 ) ;
	int b = (int)( blue( mainColor ) * ( n % 17 ) / 16.0 ) ;
	return rgb( r, v, b ) ;
}
