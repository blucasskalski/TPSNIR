var searchData=
[
  ['jbus',['jbus',['../classjbus.html',1,'jbus'],['../classjbus.html#a607fa5a14aaff1fe19f6bab1016bafde',1,'jbus::jbus()']]]
];
