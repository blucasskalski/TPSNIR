var searchData=
[
  ['api_5fmodule_5fread_5fnbits',['API_Module_Read_Nbits',['../classjbus.html#ae8cf111c9a7da12ab854a7b732dfd1c4',1,'jbus']]],
  ['api_5fmodule_5fread_5fnwords',['API_Module_Read_Nwords',['../classjbus.html#a34e99b5995c53cac450c78377d53ba93',1,'jbus']]],
  ['api_5fmodule_5fwrite_5f1word',['API_Module_Write_1word',['../classjbus.html#a1f1c12cedc4f722654442cc87cdd63e4',1,'jbus']]]
];
